package com.reflexion.kalyani.fragments

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.reflexion.kalyani.adapter.MoviesAdapter01
import com.reflexion.kalyani.adapter.MoviesAdapter02
import com.reflexion.kalyani.databinding.FragmentMoviesBinding
import com.reflexion.kalyani.model.MovieList01
import com.reflexion.kalyani.model.MovieList02
import com.reflexion.kalyani.model.Movies01
import com.reflexion.kalyani.model.Movies02
import com.reflexion.kalyani.networklayer.Api_Interface
import com.reflexion.kalyani.networklayer.RetrofitInstance
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MoviesFragment : Fragment() {
    private lateinit var binding:FragmentMoviesBinding
    private lateinit var movieslist01: ArrayList<MovieList01>
    private lateinit var movieslist02: ArrayList<MovieList02>
    private lateinit var moviesadapter01 : MoviesAdapter01
    private lateinit var moviesadapter02 : MoviesAdapter02

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentMoviesBinding.inflate(inflater, container, false)

        moviesadapter01 = MoviesAdapter01(requireContext(),movieslist01)
        binding.movieRec1.adapter = moviesadapter01
        binding.movieRec1.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)

        moviesadapter02 = MoviesAdapter02(requireContext(),movieslist02)
        binding.movieRec2.adapter = moviesadapter02
        binding.movieRec2.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)

        // function for response
        getMovie01List()
        getMovie02List()

        return binding.root
    }

    private fun getMovie01List() {
        val retrofit = RetrofitInstance.getInstance()
        val request = retrofit.create(Api_Interface::class.java)
        val call = request.getMovieList01()
        call.enqueue(object : Callback<Movies01> {
            @SuppressLint("NotifyDataSetChanged")
            override fun onResponse(call: Call<Movies01>, response: Response<Movies01>) {
                if (response.isSuccessful && response.body() != null) {
                    movieslist01.clear()
                    response.body()!!.Movie_List.let { movieslist01.addAll(it) }
                    Log.d("error", "onResponse")
                    moviesadapter01.notifyDataSetChanged()
                }

            }

            override fun onFailure(call: Call<Movies01>, t: Throwable) {
                Toast.makeText(context, "Error occurred: ${t.message}", Toast.LENGTH_SHORT).show()
                Log.e("error", "Error occurred while getting movie list", t)
            }

        })

    }

    private fun getMovie02List() {
        val retrofit = RetrofitInstance.getInstance()
        val request = retrofit.create(Api_Interface::class.java)
        val call = request.getMovieList02()
        call.enqueue(object : Callback<Movies02> {
            @SuppressLint("NotifyDataSetChanged")
            override fun onResponse(call: Call<Movies02>, response: Response<Movies02>) {
                if (response.isSuccessful && response.body() != null) {
                    movieslist02.clear()
                    response.body()!!.Movie_List.let { movieslist02.addAll(it) }
                    Log.d("error", "onResponse")
                    moviesadapter02.notifyDataSetChanged()
                }

            }

            override fun onFailure(call: Call<Movies02>, t: Throwable) {
                Toast.makeText(context, "Error occurred: ${t.message}", Toast.LENGTH_SHORT).show()
                Log.e("error", "Error occurred while getting movie list", t)
            }

        })

    }
}