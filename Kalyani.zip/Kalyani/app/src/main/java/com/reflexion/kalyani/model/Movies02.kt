package com.reflexion.kalyani.model

data class Movies02(
    val Movie_List: ArrayList<MovieList02>
)