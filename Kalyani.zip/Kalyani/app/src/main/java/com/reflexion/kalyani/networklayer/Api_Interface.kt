package com.reflexion.kalyani.networklayer

import com.reflexion.kalyani.model.Movies01
import com.reflexion.kalyani.model.Movies02
import retrofit2.Call
import retrofit2.http.GET

interface Api_Interface {

    @GET("1.json")
    fun getMovieList01() : Call<Movies01>

    @GET("2.json")
    fun getMovieList02() : Call<Movies02>
}