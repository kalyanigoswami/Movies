package com.reflexion.kalyani.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.reflexion.kalyani.R
import com.reflexion.kalyani.model.MovieList01

class MoviesAdapter01 (
    private var  context: Context,
    private var list: ArrayList<MovieList01>)
    : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater= LayoutInflater.from(parent.context)
        val view =inflater.inflate(R.layout.item_movie1,parent,false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item=list[position]
        holder as ViewHolder
        Glide.with(context).load(item.Movie_Poster).placeholder(R.drawable.ic_launcher_foreground).into(holder.moviePoster)
        holder.movieTitle.text=item.Title
        holder.movieCast.text=item.Cast
        holder.movieRunTime.text=item.Runtime
        holder.movieYear.text=item.Year
        holder.movieDirector.text=item.Director
        holder.movieRating.text=item.Rating
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var moviePoster=itemView.findViewById<ImageView>(R.id.moviePoster)
        var movieTitle=itemView.findViewById<TextView>(R.id.movieTitle)
        var movieCast=itemView.findViewById<TextView>(R.id.movieCast)
        var movieRunTime=itemView.findViewById<TextView>(R.id.movieRunTime)
        var movieYear=itemView.findViewById<TextView>(R.id.movieYear)
        var movieDirector=itemView.findViewById<TextView>(R.id.movieDirector)
        var movieRating=itemView.findViewById<TextView>(R.id.movieRating)

    }
}