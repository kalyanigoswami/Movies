package com.reflexion.kalyani.model

data class Movies01(
    val Movie_List: ArrayList<MovieList01>
)