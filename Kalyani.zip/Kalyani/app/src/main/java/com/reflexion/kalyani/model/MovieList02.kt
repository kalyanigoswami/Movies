package com.reflexion.kalyani.model

data class MovieList02(
    val Cast: String,
    val Director: String,
    val Genres: String,
    val IMDBID: String,
    val Movie_Poster: String,
    val Rating: String,
    val Runtime: String,
    val Short_Summary: String,
    val Summary: String,
    val Title: String,
    val Writers: String,
    val Year: String,
    val YouTube_Trailer: String
)