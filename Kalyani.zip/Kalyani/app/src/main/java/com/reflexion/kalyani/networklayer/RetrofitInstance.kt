package com.reflexion.kalyani.networklayer

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitInstance {
    companion object {
        private const val base_url = "http://task.auditflo.in/" //1.json //2.json
        private var retrofit : Retrofit? = null

        fun getInstance() : Retrofit {
            if (retrofit == null ) {
                retrofit = Retrofit.Builder()
                    .baseUrl(base_url)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return retrofit!!
        }
    }
}